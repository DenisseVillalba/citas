
package com.mycompany.prycitasmedicas;

import controlador.EspecialidadControlador;
import controlador.MedicoControlador;
import controlador.PacienteControlador;
import modelo.EspecialidadModelo;
import vista.Principal;


public class PryCitasMedicas {

    public static void main(String[] args) {
        //paciente
        PacienteControlador pc=PacienteControlador.getInstancia();
        pc.guardarDatos("1756143622", "Denisse", 19, false);
        pc.guardarDatos("1568954236", "Lucas", 8, true);
        pc.guardarDatos("2598456320", "Lisa", 36, false);
        //especialidad 
        EspecialidadControlador e=EspecialidadControlador.getInstancia();
        EspecialidadModelo em1= e.guardar("MEDICINA GENERAL");
        EspecialidadModelo em2= e.guardar("CARDIOLOGIA");
        EspecialidadModelo em3=e.guardar("PEDIATRIA");
        //medico
        MedicoControlador mc=MedicoControlador.getInstancia();
        mc.guardar(em1, "1718013723", "Jenny", 48, false);
        mc.guardar(em2, "2569487512", "Ricardo", 45, true);
        mc.guardar(em3, "1023695847", "Sebas", 30, false);
        
        Principal p=new Principal();
        p.setVisible(true);
        p.setLocationRelativeTo(null);
    }
}
