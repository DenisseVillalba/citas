package vista.pacientes;

import controlador.PacienteControlador;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.PacienteModelo;

public class Listado extends javax.swing.JInternalFrame {
public DefaultTableModel tableModel=new DefaultTableModel();
    PacienteControlador pc= PacienteControlador.getInstancia();
    public Listado() {
        initComponents();
        
 tbl_listado.setModel(tableModel);
        String columnas[]={"CEDULA","NOMBRES","EDAD","SEXO"};
        tableModel.setColumnIdentifiers(columnas);
        
        cargarListadoPacientes();
     
    }
private void cargarListadoPacientes(){
       for(PacienteModelo pm : pc.listadoCompleto()) {
           Object[]fila={pm.getCedula(),pm.getNombre(),pm.getEdad(),pm.getSexo()};
            tableModel.addRow(fila);
}
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtbuscarporcedula = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_listado = new javax.swing.JTable();
        btn_elimar = new javax.swing.JButton();
        btn_modificar = new javax.swing.JButton();

        jLabel1.setText("BUSCA POR CEDULA");

        txtbuscarporcedula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtbuscarporcedulaKeyReleased(evt);
            }
        });

        tbl_listado.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tbl_listado);

        btn_elimar.setText("ELIMINAR");
        btn_elimar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_elimarActionPerformed(evt);
            }
        });

        btn_modificar.setText("MODIFICAR");
        btn_modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_modificarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jLabel1)
                .addGap(39, 39, 39)
                .addComponent(txtbuscarporcedula, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_modificar)
                    .addComponent(btn_elimar)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(0, 79, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtbuscarporcedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(btn_elimar)
                .addGap(18, 18, 18)
                .addComponent(btn_modificar)
                .addContainerGap(103, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtbuscarporcedulaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtbuscarporcedulaKeyReleased
      tableModel.setRowCount(0);
        String cedula=txtbuscarporcedula.getText();
      
        for(PacienteModelo pm : pc.listadoCompletoPorCedula(cedula)) {
           Object[]fila={pm.getCedula(),pm.getNombre(),pm.getEdad(),pm.getSexo()};
            tableModel.addRow(fila);
        }
    }//GEN-LAST:event_txtbuscarporcedulaKeyReleased

    private void btn_elimarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_elimarActionPerformed
        int filaSeleccionada = tbl_listado.getSelectedRow();
    
    if (filaSeleccionada == -1) { 
        JOptionPane.showMessageDialog(this, "Seleccione un paciente para eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    
    String cedula = tbl_listado.getValueAt(filaSeleccionada, 0).toString();
    
 
    int confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de eliminar este paciente?", "Confirmar", JOptionPane.YES_NO_OPTION);
    if (confirmacion == JOptionPane.YES_OPTION) {
        
        boolean eliminado = pc.eliminarPaciente(cedula);
        
        if (eliminado) {
            JOptionPane.showMessageDialog(this, "Paciente eliminado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
            tableModel.setRowCount(0); 
            cargarListadoPacientes(); 
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo eliminar el paciente", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_btn_elimarActionPerformed

    private void btn_modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_modificarActionPerformed
         int filaSeleccionada = tbl_listado.getSelectedRow();
    
    if (filaSeleccionada == -1) { 
        JOptionPane.showMessageDialog(this, "Seleccione un paciente para modificar", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    
    String cedula = tbl_listado.getValueAt(filaSeleccionada, 0).toString();
    String nombre = tbl_listado.getValueAt(filaSeleccionada, 1).toString();
    int edad = Integer.parseInt(tbl_listado.getValueAt(filaSeleccionada, 2).toString());
    String sexo = tbl_listado.getValueAt(filaSeleccionada, 3).toString();
    
    
    String nuevoNombre = JOptionPane.showInputDialog(this, "Nuevo nombre:", nombre);
    String nuevaEdadStr = JOptionPane.showInputDialog(this, "Nueva edad:", edad);
    String nuevoSexo = JOptionPane.showInputDialog(this, "Nuevo sexo (HOMBRE/MUJER):", sexo);
    
    if (nuevoNombre != null && nuevaEdadStr != null && nuevoSexo != null) {
        try {
            int nuevaEdad = Integer.parseInt(nuevaEdadStr);
            boolean nuevoSexoBool = nuevoSexo.equalsIgnoreCase("HOMBRE");
            
            
            boolean modificado = pc.modificarPaciente(cedula, nuevoNombre, nuevaEdad, nuevoSexoBool);
            
            if (modificado) {
                JOptionPane.showMessageDialog(this, "Paciente modificado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                
                tableModel.setRowCount(0); 
                cargarListadoPacientes(); 
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo modificar el paciente", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La edad debe ser un número válido", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_btn_modificarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_elimar;
    private javax.swing.JButton btn_modificar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_listado;
    private javax.swing.JTextField txtbuscarporcedula;
    // End of variables declaration//GEN-END:variables
}
