package vista.medicos;

import controlador.EspecialidadControlador;
import controlador.MedicoControlador;
import vista.pacientes.*;
import controlador.PacienteControlador;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.EspecialidadModelo;
import modelo.MedicoModelo;
import modelo.PacienteModelo;


public class Listado extends javax.swing.JInternalFrame {
public DefaultTableModel tableModel=new DefaultTableModel();
    MedicoControlador mc=MedicoControlador.getInstancia();
    public Listado() {
        initComponents();
        
 tbl_listado.setModel(tableModel);
        String columnas[]={"CEDULA","NOMBRES","EDAD","SEXO","ESPECIALIDAD"};
        tableModel.setColumnIdentifiers(columnas);
        
        cargarListadoMedico();
     
    }
private void cargarListadoMedico(){
       for(MedicoModelo pm : mc.listadoCompleto()) {
           Object[]fila={pm.getCedula(),pm.getNombre(),pm.getEdad(),pm.getSexo(),pm.getModelo().getNombre()};
            tableModel.addRow(fila);
}
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtbuscarporcedula = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_listado = new javax.swing.JTable();
        btn_eliminar = new javax.swing.JButton();
        btn_modificar = new javax.swing.JButton();

        jLabel1.setText("BUSCA POR CEDULA");

        txtbuscarporcedula.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtbuscarporcedulaKeyReleased(evt);
            }
        });

        tbl_listado.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {},
                {},
                {},
                {}
            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tbl_listado);

        btn_eliminar.setText("ELIMINAR");
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });

        btn_modificar.setText("MODIFICAR");
        btn_modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_modificarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(12, 12, 12)
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtbuscarporcedula, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 94, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_modificar)
                    .addComponent(btn_eliminar))
                .addGap(69, 69, 69))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtbuscarporcedula, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 199, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(btn_eliminar)
                .addGap(18, 18, 18)
                .addComponent(btn_modificar)
                .addContainerGap(80, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtbuscarporcedulaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtbuscarporcedulaKeyReleased
      tableModel.setRowCount(0);
        String cedula=txtbuscarporcedula.getText();
      
        for(MedicoModelo pm : mc.listadoCompletoPorCedula(cedula)) {
           Object[]fila={pm.getCedula(),pm.getNombre(),pm.getEdad(),pm.getSexo(),pm.getModelo().getNombre()};
            tableModel.addRow(fila);
        }
    }//GEN-LAST:event_txtbuscarporcedulaKeyReleased

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        int filaSeleccionada = tbl_listado.getSelectedRow();
    
    if (filaSeleccionada == -1) { 
        JOptionPane.showMessageDialog(this, "Seleccione un médico para eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
   
    String cedula = tbl_listado.getValueAt(filaSeleccionada, 0).toString();
    
  
    int confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de eliminar este médico?", "Confirmar", JOptionPane.YES_NO_OPTION);
    if (confirmacion == JOptionPane.YES_OPTION) {
      
        boolean eliminado = mc.eliminarMedico(cedula);
        
        if (eliminado) {
            JOptionPane.showMessageDialog(this, "Médico eliminado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            // Actualizar la tabla
            tableModel.setRowCount(0); 
            cargarListadoMedico(); 
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo eliminar el médico", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_btn_eliminarActionPerformed

    private void btn_modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_modificarActionPerformed
        int filaSeleccionada = tbl_listado.getSelectedRow();
    
    if (filaSeleccionada == -1) { 
        JOptionPane.showMessageDialog(this, "Seleccione un médico para modificar", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    
    String cedula = tbl_listado.getValueAt(filaSeleccionada, 0).toString();
    String nombre = tbl_listado.getValueAt(filaSeleccionada, 1).toString();
    int edad = Integer.parseInt(tbl_listado.getValueAt(filaSeleccionada, 2).toString());
    String sexo = tbl_listado.getValueAt(filaSeleccionada, 3).toString();
    String especialidad = tbl_listado.getValueAt(filaSeleccionada, 4).toString();
    
    
    String nuevoNombre = JOptionPane.showInputDialog(this, "Nuevo nombre:", nombre);
    String nuevaEdadStr = JOptionPane.showInputDialog(this, "Nueva edad:", edad);
    String nuevoSexo = JOptionPane.showInputDialog(this, "Nuevo sexo (HOMBRE/MUJER):", sexo);
    String nuevaEspecialidad = JOptionPane.showInputDialog(this, "Nueva especialidad:", especialidad);
    
    if (nuevoNombre != null && nuevaEdadStr != null && nuevoSexo != null && nuevaEspecialidad != null) {
        try {
            int nuevaEdad = Integer.parseInt(nuevaEdadStr);
            boolean nuevoSexoBool = nuevoSexo.equalsIgnoreCase("HOMBRE");
            
            
            EspecialidadControlador ec = EspecialidadControlador.getInstancia();
            EspecialidadModelo nuevaEspecialidadModelo = ec.obtenerPorNombre(nuevaEspecialidad);
            
            if (nuevaEspecialidadModelo == null) {
                JOptionPane.showMessageDialog(this, "Especialidad no válida", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            
            
            boolean modificado = mc.modificarMedico(cedula, nuevoNombre, nuevaEdad, nuevoSexoBool, nuevaEspecialidadModelo);
            
            if (modificado) {
                JOptionPane.showMessageDialog(this, "Médico modificado correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
                
                tableModel.setRowCount(0); 
                cargarListadoMedico(); 
            } else {
                JOptionPane.showMessageDialog(this, "No se pudo modificar el médico", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "La edad debe ser un número válido", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_btn_modificarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JButton btn_modificar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_listado;
    private javax.swing.JTextField txtbuscarporcedula;
    // End of variables declaration//GEN-END:variables
}
