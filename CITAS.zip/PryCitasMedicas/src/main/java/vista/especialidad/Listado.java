
package vista.especialidad;

import controlador.EspecialidadControlador;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.EspecialidadModelo;

public class Listado extends javax.swing.JInternalFrame {
    EspecialidadControlador e=EspecialidadControlador.getInstancia();
    DefaultTableModel defaultTableModel=new DefaultTableModel();
    
    public Listado() {
        initComponents();
        tblListado.setModel(defaultTableModel);
        String columnas[]={"NOMBRE"};
        defaultTableModel.setColumnIdentifiers(columnas);
     CargarListado();
    }
private void CargarListado(){
      for (EspecialidadModelo modelo : e.listado()) {
            Object[] fila={modelo.getNombre()};
            defaultTableModel.addRow(fila);
        }
}
   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        txtBuscar = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblListado = new javax.swing.JTable();
        btn_modifi = new javax.swing.JButton();
        btn_elimi = new javax.swing.JButton();

        jLabel1.setText("BUSCAR POR NOMBRE");

        txtBuscar.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtBuscarKeyReleased(evt);
            }
        });

        tblListado.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tblListado);

        btn_modifi.setText("ELIMINAR");
        btn_modifi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_modifiActionPerformed(evt);
            }
        });

        btn_elimi.setText("MODIFICAR");
        btn_elimi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_elimiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 235, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 320, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(96, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_elimi)
                    .addComponent(btn_modifi))
                .addGap(88, 88, 88))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 191, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btn_modifi)
                .addGap(28, 28, 28)
                .addComponent(btn_elimi)
                .addContainerGap(77, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void txtBuscarKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtBuscarKeyReleased
         defaultTableModel.setRowCount(0);
        String nombre=txtBuscar.getText();
      
        for(EspecialidadModelo ee : e.listadoCompletoPorNombre(nombre)) {
           Object[]fila={ee.getNombre()};
            defaultTableModel.addRow(fila);
        }
    }//GEN-LAST:event_txtBuscarKeyReleased

    private void btn_modifiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_modifiActionPerformed
        int filaSeleccionada = tblListado.getSelectedRow();
    
    if (filaSeleccionada == -1) { // Si no hay fila seleccionada
        JOptionPane.showMessageDialog(this, "Seleccione una especialidad para eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
 
    String nombre = tblListado.getValueAt(filaSeleccionada, 0).toString();
    
   
    int confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de eliminar esta especialidad?", "Confirmar", JOptionPane.YES_NO_OPTION);
    if (confirmacion == JOptionPane.YES_OPTION) {
        
        boolean eliminado = e.eliminarEspecialidad(nombre);
        
        if (eliminado) {
            JOptionPane.showMessageDialog(this, "Especialidad eliminada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            
            defaultTableModel.setRowCount(0); 
            CargarListado(); 
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo eliminar la especialidad", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_btn_modifiActionPerformed

    private void btn_elimiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_elimiActionPerformed
        int filaSeleccionada = tblListado.getSelectedRow();
    
    if (filaSeleccionada == -1) { // Si no hay fila seleccionada
        JOptionPane.showMessageDialog(this, "Seleccione una especialidad para modificar", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    

    String nombre = tblListado.getValueAt(filaSeleccionada, 0).toString();
 
    String nuevoNombre = JOptionPane.showInputDialog(this, "Nuevo nombre:", nombre);
    
    if (nuevoNombre != null && !nuevoNombre.isEmpty()) {

        boolean modificado = e.modificarEspecialidad(nombre, nuevoNombre);
        
        if (modificado) {
            JOptionPane.showMessageDialog(this, "Especialidad modificada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
          
            defaultTableModel.setRowCount(0); // Limpiar la tabla
            CargarListado(); 
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo modificar la especialidad", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_btn_elimiActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_elimi;
    private javax.swing.JButton btn_modifi;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tblListado;
    private javax.swing.JTextField txtBuscar;
    // End of variables declaration//GEN-END:variables
}
