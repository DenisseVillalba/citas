package vista;

import vista.pacientes.Ingresar;
import vista.pacientes.Listado;

public class Principal extends javax.swing.JFrame {

    public Principal() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        contenedor_Principal = new javax.swing.JDesktopPane();
        jMenuBar1 = new javax.swing.JMenuBar();
        jMenu1 = new javax.swing.JMenu();
        jMenu2 = new javax.swing.JMenu();
        menu_ingresar_paciente = new javax.swing.JMenuItem();
        menu_listado_paciente = new javax.swing.JMenuItem();
        jMenu3 = new javax.swing.JMenu();
        especialidadIngresar = new javax.swing.JMenuItem();
        listadoEspecialidad = new javax.swing.JMenuItem();
        jMenu4 = new javax.swing.JMenu();
        IngresarMedicoMenu = new javax.swing.JMenuItem();
        ListadoMedicoMenu = new javax.swing.JMenuItem();
        jMenu5 = new javax.swing.JMenu();
        IngresarCita = new javax.swing.JMenuItem();
        ListadoCita = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout contenedor_PrincipalLayout = new javax.swing.GroupLayout(contenedor_Principal);
        contenedor_Principal.setLayout(contenedor_PrincipalLayout);
        contenedor_PrincipalLayout.setHorizontalGroup(
            contenedor_PrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 660, Short.MAX_VALUE)
        );
        contenedor_PrincipalLayout.setVerticalGroup(
            contenedor_PrincipalLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 325, Short.MAX_VALUE)
        );

        jMenu1.setText("INICIO");
        jMenuBar1.add(jMenu1);

        jMenu2.setText("PACIENTES");

        menu_ingresar_paciente.setText("INGRESAR");
        menu_ingresar_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_ingresar_pacienteActionPerformed(evt);
            }
        });
        jMenu2.add(menu_ingresar_paciente);

        menu_listado_paciente.setText("LISTAR");
        menu_listado_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                menu_listado_pacienteActionPerformed(evt);
            }
        });
        jMenu2.add(menu_listado_paciente);

        jMenuBar1.add(jMenu2);

        jMenu3.setText("ESPECIALIDADES");

        especialidadIngresar.setText("INGRESAR");
        especialidadIngresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                especialidadIngresarActionPerformed(evt);
            }
        });
        jMenu3.add(especialidadIngresar);

        listadoEspecialidad.setText("LISTADO");
        listadoEspecialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                listadoEspecialidadActionPerformed(evt);
            }
        });
        jMenu3.add(listadoEspecialidad);

        jMenuBar1.add(jMenu3);

        jMenu4.setText("MEDICOS");

        IngresarMedicoMenu.setText("INGRESAR");
        IngresarMedicoMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngresarMedicoMenuActionPerformed(evt);
            }
        });
        jMenu4.add(IngresarMedicoMenu);

        ListadoMedicoMenu.setText("LISTADO");
        ListadoMedicoMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListadoMedicoMenuActionPerformed(evt);
            }
        });
        jMenu4.add(ListadoMedicoMenu);

        jMenuBar1.add(jMenu4);

        jMenu5.setText("CITAS");

        IngresarCita.setText("INGRESAR");
        IngresarCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                IngresarCitaActionPerformed(evt);
            }
        });
        jMenu5.add(IngresarCita);

        ListadoCita.setText("LISTADO");
        ListadoCita.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ListadoCitaActionPerformed(evt);
            }
        });
        jMenu5.add(ListadoCita);

        jMenuBar1.add(jMenu5);

        setJMenuBar(jMenuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contenedor_Principal)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(contenedor_Principal)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menu_ingresar_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_ingresar_pacienteActionPerformed
    
    contenedor_Principal.removeAll();
        Ingresar i=new Ingresar();
        contenedor_Principal.add(i).setVisible(true);
    }//GEN-LAST:event_menu_ingresar_pacienteActionPerformed

    private void menu_listado_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_menu_listado_pacienteActionPerformed
        
        contenedor_Principal.removeAll();
        contenedor_Principal.add(new Listado()).setVisible(true);
    }//GEN-LAST:event_menu_listado_pacienteActionPerformed

    private void especialidadIngresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_especialidadIngresarActionPerformed
        contenedor_Principal.removeAll();
        contenedor_Principal.add(new vista.especialidad.Ingresar()).setVisible(true);
    }//GEN-LAST:event_especialidadIngresarActionPerformed

    private void listadoEspecialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_listadoEspecialidadActionPerformed
        
        contenedor_Principal.removeAll();
        contenedor_Principal.add(new vista.especialidad.Listado()).setVisible(true);
    }//GEN-LAST:event_listadoEspecialidadActionPerformed

    private void IngresarMedicoMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IngresarMedicoMenuActionPerformed
       
         contenedor_Principal.removeAll();
        contenedor_Principal.add(new vista.medicos.Ingresar()).setVisible(true);
    }//GEN-LAST:event_IngresarMedicoMenuActionPerformed

    private void ListadoMedicoMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListadoMedicoMenuActionPerformed
        
         contenedor_Principal.removeAll();
        contenedor_Principal.add(new vista.medicos.Listado()).setVisible(true);
    }//GEN-LAST:event_ListadoMedicoMenuActionPerformed

    private void IngresarCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_IngresarCitaActionPerformed
        
         contenedor_Principal.removeAll();
       contenedor_Principal.add(new vista.citas.Ingresar()).setVisible(true);
    }//GEN-LAST:event_IngresarCitaActionPerformed

    private void ListadoCitaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ListadoCitaActionPerformed
      
         contenedor_Principal.removeAll();
       contenedor_Principal.add(new vista.citas.Listado()).setVisible(true);
    }//GEN-LAST:event_ListadoCitaActionPerformed

   
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Principal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem IngresarCita;
    private javax.swing.JMenuItem IngresarMedicoMenu;
    private javax.swing.JMenuItem ListadoCita;
    private javax.swing.JMenuItem ListadoMedicoMenu;
    private javax.swing.JDesktopPane contenedor_Principal;
    private javax.swing.JMenuItem especialidadIngresar;
    private javax.swing.JMenu jMenu1;
    private javax.swing.JMenu jMenu2;
    private javax.swing.JMenu jMenu3;
    private javax.swing.JMenu jMenu4;
    private javax.swing.JMenu jMenu5;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JMenuItem listadoEspecialidad;
    private javax.swing.JMenuItem menu_ingresar_paciente;
    private javax.swing.JMenuItem menu_listado_paciente;
    // End of variables declaration//GEN-END:variables
}
