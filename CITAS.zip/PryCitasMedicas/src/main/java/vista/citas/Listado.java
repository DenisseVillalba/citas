
package vista.citas;

import controlador.CitaControlador;
import controlador.MedicoControlador;
import controlador.PacienteControlador;
import controlador.EspecialidadControlador;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import modelo.CitaModelo;
import modelo.EspecialidadModelo;
import modelo.MedicoModelo;
import modelo.PacienteModelo;


    public class Listado extends javax.swing.JInternalFrame {
    PacienteControlador pc=PacienteControlador.getInstancia();
    EspecialidadControlador ec=EspecialidadControlador.getInstancia();
    MedicoControlador mc=MedicoControlador.getInstancia();
    CitaControlador cc=CitaControlador.getInstancia();
    DefaultTableModel defaultTableModel=new DefaultTableModel();
    
    public Listado() {
        initComponents();
      
        cargarPacienteAutomaticamente();
        cargarEspecialidadAutomaticamente();
        cargarMedicoAutomaticamente();
        cargarEstadoAutomaticamente();
         cbx_estado.setEditable(false);  
        
        tbl_Listado_cita.setModel(defaultTableModel);
          String columnas[] = {"PACIENTE", "ESPECIALIDAD", "MEDICO", "DESCRIPCION", "HORA", "FECHA", "ESTADO"};
        defaultTableModel.setColumnIdentifiers(columnas);
        tbl_Listado_cita.setModel(defaultTableModel);
          CargarListadoTotal();
         
   
    }
        private void cargarPacienteAutomaticamente(){
            for (PacienteModelo pm : pc.listadoCompleto()) {
            cbx_paciente.addItem(pm.getNombre());
        }
    }      
        private void cargarEspecialidadAutomaticamente(){
               for (EspecialidadModelo modelo : ec.listado()) {
            cbx_especialidad.addItem(modelo.getNombre());
        }
    }
        private void cargarMedicoAutomaticamente(){
              for (MedicoModelo mm : mc.listadoCompleto()) {
            cbx_medico.addItem(mm.getNombre());
        }
    }
        private void cargarEstadoAutomaticamente() {
    
        cbx_estado.removeAllItems();

    
        cbx_estado.addItem("ATENDIDO");
        cbx_estado.addItem("NO ATENDIDO");
    }
        private void CargarListadoTotal() {
    
         defaultTableModel.setRowCount(0);

   
          for (CitaModelo cm : cc.listadoCompleto()) {
        
            if (cm.getPm() != null && cm.getEm() != null && cm.getMm() != null &&
            cm.getDescripcion() != null && !cm.getDescripcion().isEmpty() &&
            cm.getFecha() != null && !cm.getFecha().isEmpty() &&
            cm.getHora() != null && !cm.getHora().isEmpty()) {
            
            
            Object[] fila = {
                cm.getPm().getNombre(),  
                cm.getEm().getNombre(),  
                cm.getMm().getNombre(),  
                cm.getDescripcion(),     
                cm.getFecha(),           
                cm.getHora() ,           
                cm.getEstadoTexto()      
            };

            
            defaultTableModel.addRow(fila);
        }
    }
}
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cbx_paciente = new javax.swing.JComboBox<>();
        cbx_especialidad = new javax.swing.JComboBox<>();
        cbx_medico = new javax.swing.JComboBox<>();
        txt_fecha = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_Listado_cita = new javax.swing.JTable();
        jLabel5 = new javax.swing.JLabel();
        cbx_estado = new javax.swing.JComboBox<>();
        jLabel6 = new javax.swing.JLabel();
        btn_mostarcitas = new javax.swing.JButton();
        btn_eliminar = new javax.swing.JButton();
        btn_modificar = new javax.swing.JButton();

        jLabel1.setText("SELECCIONAR PACIENTE");

        jLabel2.setText("SELECCIONAR ESPECIALIDAD");

        jLabel3.setText("SELECCIONAR MEDICO");

        jLabel4.setText("ESCRIBA LA FECHA");

        cbx_paciente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbx_pacienteActionPerformed(evt);
            }
        });

        cbx_especialidad.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbx_especialidadActionPerformed(evt);
            }
        });

        cbx_medico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbx_medicoActionPerformed(evt);
            }
        });

        txt_fecha.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txt_fechaKeyReleased(evt);
            }
        });

        tbl_Listado_cita.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane1.setViewportView(tbl_Listado_cita);

        jLabel5.setText("BUSCAR POR ESTADO");

        cbx_estado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbx_estadoActionPerformed(evt);
            }
        });

        jLabel6.setText("LISTADO CITAS MEDICAS");

        btn_mostarcitas.setText("MOSTRAR TODO");
        btn_mostarcitas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_mostarcitasActionPerformed(evt);
            }
        });

        btn_eliminar.setText("ELIMINAR");
        btn_eliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_eliminarActionPerformed(evt);
            }
        });

        btn_modificar.setText("MODIFICAR");
        btn_modificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_modificarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(240, 240, 240)
                .addComponent(jLabel6)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(51, 51, 51)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(45, 45, 45)
                                .addComponent(cbx_estado, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(196, 196, 196))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel1))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(cbx_medico, javax.swing.GroupLayout.Alignment.LEADING, 0, 566, Short.MAX_VALUE)
                                    .addComponent(txt_fecha, javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cbx_especialidad, javax.swing.GroupLayout.Alignment.LEADING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(cbx_paciente, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jScrollPane1))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(324, 324, 324)
                                .addComponent(btn_mostarcitas))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(258, 258, 258)
                                .addComponent(btn_eliminar)
                                .addGap(100, 100, 100)
                                .addComponent(btn_modificar)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel6)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5)
                    .addComponent(cbx_estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cbx_paciente, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cbx_especialidad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3)
                    .addComponent(cbx_medico, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addComponent(txt_fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btn_mostarcitas)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 214, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_eliminar)
                    .addComponent(btn_modificar)))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cbx_pacienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbx_pacienteActionPerformed

    defaultTableModel.setRowCount(0);

    
    String nombrePaciente = cbx_paciente.getSelectedItem().toString();

    
    for (CitaModelo cm : cc.listadoCompletoPorPaciente(nombrePaciente)) {
        
        if (cm.getPm() != null && cm.getEm() != null && cm.getMm() != null &&
            cm.getDescripcion() != null && cm.getFecha() != null && cm.getHora() != null) {
            
            
            Object[] fila = {
                cm.getPm().getNombre(),  
                cm.getEm().getNombre(),  
                cm.getMm().getNombre(),  
                cm.getDescripcion(),     
                cm.getFecha(),          
                cm.getHora(),            
                cm.getEstadoTexto()
            };

            
            defaultTableModel.addRow(fila);
        }
    }
    }//GEN-LAST:event_cbx_pacienteActionPerformed

    private void cbx_especialidadActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbx_especialidadActionPerformed
      
    defaultTableModel.setRowCount(0);

    
    String nombreEspecialidad = cbx_especialidad.getSelectedItem().toString();

    
    for (CitaModelo cm : cc.listadoCompletoPorEspecialidad(nombreEspecialidad)) {
        
        if (cm.getPm() != null && cm.getEm() != null && cm.getMm() != null &&
            cm.getDescripcion() != null && cm.getFecha() != null && cm.getHora() != null) {
            
            
            Object[] fila = {
                cm.getPm().getNombre(),  
                cm.getEm().getNombre(),  
                cm.getMm().getNombre(),  
                cm.getDescripcion(),     
                cm.getFecha(),           
                cm.getHora(),             
                cm.getEstadoTexto()
            };

            
            defaultTableModel.addRow(fila);
        }
    }
    }//GEN-LAST:event_cbx_especialidadActionPerformed

    private void cbx_medicoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbx_medicoActionPerformed
    
    defaultTableModel.setRowCount(0);

    
    String nombreMedico = cbx_medico.getSelectedItem().toString();

    
    for (CitaModelo cm : cc.listadoCompletoPorMedico(nombreMedico)) {
        
        if (cm.getPm() != null && cm.getEm() != null && cm.getMm() != null &&
            cm.getDescripcion() != null && cm.getFecha() != null && cm.getHora() != null) {
            
            
            Object[] fila = {
                cm.getPm().getNombre(),  
                cm.getEm().getNombre(),  
                cm.getMm().getNombre(),  
                cm.getDescripcion(),    
                cm.getFecha(),           
                cm.getHora() ,            
                cm.getEstadoTexto()
            };

            
            defaultTableModel.addRow(fila);
        }
    }
    }//GEN-LAST:event_cbx_medicoActionPerformed

    private void txt_fechaKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txt_fechaKeyReleased
          defaultTableModel.setRowCount(0);
        String fecha=txt_fecha.getText();
      
        for(CitaModelo cm : cc.listadoCompletoPorFecha(fecha)) {
           Object[]fila={ cm.getPm().getNombre(),  
                cm.getEm().getNombre(),  
                cm.getMm().getNombre(),  
                cm.getDescripcion(),     
                cm.getFecha(),           
                cm.getHora(),
                cm.getEstadoTexto()
           };
             
            defaultTableModel.addRow(fila);
        }
    }//GEN-LAST:event_txt_fechaKeyReleased

    private void cbx_estadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbx_estadoActionPerformed
       
    defaultTableModel.setRowCount(0);

    
    String estadoSeleccionado = cbx_estado.getSelectedItem().toString();

   
    boolean atendido = false;
    if (estadoSeleccionado.equalsIgnoreCase("ATENDIDO")) {
        atendido = true;
    } else if (estadoSeleccionado.equalsIgnoreCase("NO ATENDIDO")) {
        atendido = false;
    }

    
    List<CitaModelo> citasFiltradas = cc.listadoCompletoPorEstado(atendido);

    
    for (CitaModelo cm : citasFiltradas) {
        
        if (cm.getPm() != null && cm.getEm() != null && cm.getMm() != null &&
            cm.getDescripcion() != null && cm.getFecha() != null && cm.getHora() != null) {
            
            Object[] fila = {
                cm.getPm().getNombre(),  
                cm.getEm().getNombre(),  
                cm.getMm().getNombre(),  
                cm.getDescripcion(),     
                cm.getFecha(),           
                cm.getHora(),            
                cm.getEstadoTexto()      
            };

            
            defaultTableModel.addRow(fila);
        }
    }

    }//GEN-LAST:event_cbx_estadoActionPerformed

    private void btn_mostarcitasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_mostarcitasActionPerformed
        CargarListadoTotal();
    }//GEN-LAST:event_btn_mostarcitasActionPerformed

    private void btn_eliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_eliminarActionPerformed
        int filaSeleccionada = tbl_Listado_cita.getSelectedRow();
    
    if (filaSeleccionada == -1) { // Si no hay fila seleccionada
        JOptionPane.showMessageDialog(this, "Seleccione una cita para eliminar", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    // Obtener los datos de la cita seleccionada
    String fecha = tbl_Listado_cita.getValueAt(filaSeleccionada, 4).toString();
    String hora = tbl_Listado_cita.getValueAt(filaSeleccionada, 5).toString();
    String paciente = tbl_Listado_cita.getValueAt(filaSeleccionada, 0).toString();
    String medico = tbl_Listado_cita.getValueAt(filaSeleccionada, 2).toString();
    
    // Confirmar la eliminación
    int confirmacion = JOptionPane.showConfirmDialog(this, "¿Está seguro de eliminar esta cita?", "Confirmar", JOptionPane.YES_NO_OPTION);
    if (confirmacion == JOptionPane.YES_OPTION) {
        // Llamar al método del controlador para eliminar la cita
        boolean eliminado = cc.eliminarCita(fecha, hora, paciente, medico);
        
        if (eliminado) {
            JOptionPane.showMessageDialog(this, "Cita eliminada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            // Actualizar la tabla
            defaultTableModel.setRowCount(0); // Limpiar la tabla
            CargarListadoTotal(); // Volver a cargar los datos
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo eliminar la cita", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    }//GEN-LAST:event_btn_eliminarActionPerformed

    private void btn_modificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_modificarActionPerformed
        int filaSeleccionada = tbl_Listado_cita.getSelectedRow();
    
    if (filaSeleccionada == -1) { // Si no hay fila seleccionada
        JOptionPane.showMessageDialog(this, "Seleccione una cita para modificar", "Error", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    // Obtener los datos de la cita seleccionada
    String fechaActual = tbl_Listado_cita.getValueAt(filaSeleccionada, 4).toString();
    String horaActual = tbl_Listado_cita.getValueAt(filaSeleccionada, 5).toString();
    String pacienteActual = tbl_Listado_cita.getValueAt(filaSeleccionada, 0).toString();
    String medicoActual = tbl_Listado_cita.getValueAt(filaSeleccionada, 2).toString();
    String especialidadActual = tbl_Listado_cita.getValueAt(filaSeleccionada, 1).toString();
    String descripcionActual = tbl_Listado_cita.getValueAt(filaSeleccionada, 3).toString();
    String estadoActual = tbl_Listado_cita.getValueAt(filaSeleccionada, 6).toString();
    
    // Solicitar al usuario que ingrese nuevos valores para todas las columnas
    String nuevoPaciente = JOptionPane.showInputDialog(this, "Nuevo Paciente:", pacienteActual);
    String nuevaEspecialidad = JOptionPane.showInputDialog(this, "Nueva Especialidad:", especialidadActual);
    String nuevoMedico = JOptionPane.showInputDialog(this, "Nuevo Médico:", medicoActual);
    String nuevaFecha = JOptionPane.showInputDialog(this, "Nueva Fecha (Formato: YYYY-MM-DD):", fechaActual);
    String nuevaHora = JOptionPane.showInputDialog(this, "Nueva Hora (Formato: HH:MM):", horaActual);
    String nuevaDescripcion = JOptionPane.showInputDialog(this, "Nueva Descripción:", descripcionActual);
    String nuevoEstado = JOptionPane.showInputDialog(this, "Nuevo Estado (ATENDIDO/NO ATENDIDO):", estadoActual);
    
    // Validar que todos los campos se hayan ingresado
    if (nuevoPaciente != null && nuevaEspecialidad != null && nuevoMedico != null &&
        nuevaFecha != null && nuevaHora != null && nuevaDescripcion != null && nuevoEstado != null) {
        
        // Convertir el estado a booleano
        boolean nuevoEstadoBool = nuevoEstado.equalsIgnoreCase("ATENDIDO");
        
        // Llamar al método del controlador para modificar la cita
        boolean modificado = cc.modificarCita(
            fechaActual, horaActual, pacienteActual, medicoActual, // Datos actuales para buscar la cita
            nuevaFecha, nuevaHora, nuevoPaciente, nuevoMedico, nuevaEspecialidad, nuevaDescripcion, nuevoEstadoBool // Nuevos datos
        );
        
        if (modificado) {
            JOptionPane.showMessageDialog(this, "Cita modificada correctamente", "Éxito", JOptionPane.INFORMATION_MESSAGE);
            // Actualizar la tabla
            defaultTableModel.setRowCount(0); // Limpiar la tabla
            CargarListadoTotal(); // Volver a cargar los datos
        } else {
            JOptionPane.showMessageDialog(this, "No se pudo modificar la cita", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } else {
        JOptionPane.showMessageDialog(this, "Debe ingresar todos los campos", "Error", JOptionPane.ERROR_MESSAGE);
    }
    
    }//GEN-LAST:event_btn_modificarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_eliminar;
    private javax.swing.JButton btn_modificar;
    private javax.swing.JButton btn_mostarcitas;
    private javax.swing.JComboBox<String> cbx_especialidad;
    private javax.swing.JComboBox<String> cbx_estado;
    private javax.swing.JComboBox<String> cbx_medico;
    private javax.swing.JComboBox<String> cbx_paciente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable tbl_Listado_cita;
    private javax.swing.JTextField txt_fecha;
    // End of variables declaration//GEN-END:variables
}
