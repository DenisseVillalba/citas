
package vista.citas;

import controlador.CitaControlador;
import controlador.EspecialidadControlador;
import controlador.MedicoControlador;
import controlador.PacienteControlador;
import javax.swing.JOptionPane;
import modelo.CitaModelo;
import modelo.EspecialidadModelo;
import modelo.MedicoModelo;
import modelo.PacienteModelo;

public class Ingresar extends javax.swing.JInternalFrame {

    PacienteControlador pc=PacienteControlador.getInstancia();
    EspecialidadControlador e= EspecialidadControlador.getInstancia();
    MedicoControlador mc=MedicoControlador.getInstancia();
    CitaControlador cc=CitaControlador.getInstancia();
    
    public Ingresar() {
        initComponents();
        cargarPacienteAutomaticamente();
        cargarEspecialidadAutomaticamente();
 
        cbx_especialidades.addActionListener(e->{
    
        String nombre_especialidad = cbx_especialidades.getSelectedItem().toString();
  
        if(!nombre_especialidad.equals("SELECCIONE ESPECIALIDAD")){
         
        cargarMedicosAutomaticament(nombre_especialidad);
     }
 });
    }
        private void cargarPacienteAutomaticamente(){
       
        for (PacienteModelo pm : pc.listadoCompleto()) {
            cbx_pacientes.addItem(pm.getCedula()+" "+pm.getNombre());
        }
    }
        private void cargarMedicosAutomaticament(String n){
            cbx_medicos.removeAllItems();
        for (MedicoModelo mm : mc.listadoPorEspecialidad(n)) {
            cbx_medicos.addItem(mm.getCedula()+" "+mm.getNombre());
    }
}
        private void cargarEspecialidadAutomaticamente(){
             cbx_especialidades.addItem("SELECCIONE ESPECIALIDAD");
        for (EspecialidadModelo em : e.listado()) {
            cbx_especialidades.addItem(em.getNombre());
        }
}


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        cbx_pacientes = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        cbx_especialidades = new javax.swing.JComboBox<>();
        jLabel3 = new javax.swing.JLabel();
        cbx_medicos = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_descripcion = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        txt_fecha = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txt_hora = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        btn_guardar = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        cbx_estado = new javax.swing.JComboBox<>();

        jLabel1.setText("SELECCIONAR PACIENTE");

        jLabel2.setText("SELECCIONE ESPECIALIDAD");

        jLabel3.setText("SELECCIONE MEDICO");

        jLabel4.setText("¿PARA QUE NECESITA LA CITA?");

        txt_descripcion.setColumns(20);
        txt_descripcion.setRows(5);
        jScrollPane1.setViewportView(txt_descripcion);

        jLabel5.setText("FECHA");

        jLabel6.setText("HORA");

        jLabel7.setText("D . M . AÑO");

        jLabel8.setText("HH : MM ");

        btn_guardar.setText("GENERAR TURNO");
        btn_guardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_guardarActionPerformed(evt);
            }
        });

        jLabel9.setText("ESTADO DE LA CITA");

        cbx_estado.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "ATENDIDO", "NO ATENDIDO" }));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btn_guardar, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(76, 76, 76))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel1)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(cbx_pacientes, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(cbx_especialidades, javax.swing.GroupLayout.PREFERRED_SIZE, 273, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(layout.createSequentialGroup()
                            .addComponent(jLabel3)
                            .addGap(18, 18, 18)
                            .addComponent(cbx_medicos, javax.swing.GroupLayout.PREFERRED_SIZE, 299, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(jLabel4)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 356, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel6)
                                    .addGap(18, 18, 18)
                                    .addComponent(txt_hora))
                                .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                    .addComponent(jLabel5)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                    .addComponent(txt_fecha, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGap(34, 34, 34)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel7)
                                .addComponent(jLabel8))))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(cbx_estado, javax.swing.GroupLayout.PREFERRED_SIZE, 215, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(47, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cbx_pacientes, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cbx_especialidades, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cbx_medicos, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(txt_fecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_hora, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel8)))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(cbx_estado, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addComponent(btn_guardar)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_guardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_guardarActionPerformed
     
        //validar que el campo este lleno 
        
    if (cbx_pacientes.getSelectedItem() == null || cbx_especialidades.getSelectedItem() == null ||
        cbx_medicos.getSelectedItem() == null || txt_descripcion.getText().trim().isEmpty() ||
        txt_fecha.getText().trim().isEmpty() || txt_hora.getText().trim().isEmpty() ||
        cbx_estado.getSelectedItem() == null) { 
        JOptionPane.showMessageDialog(this, "Todos los campos son obligatorios. Complete todos los datos.", "NO VALIDO", JOptionPane.ERROR_MESSAGE);
        return;
    }

    
    String especialidadSeleccionada = cbx_especialidades.getSelectedItem().toString();
    if (especialidadSeleccionada.equalsIgnoreCase("SELECCIONE ESPECIALIDAD")) {
        JOptionPane.showMessageDialog(this, "Seleccione una especialidad valida.", "NO VALIDO", JOptionPane.ERROR_MESSAGE);
        return;
    }

    //validar la fecha dia mes y año
    String fecha = txt_fecha.getText().trim();
    if (!fecha.matches("\\d{2}.\\d{2}.\\d{4}")) {
        JOptionPane.showMessageDialog(this, "Formato de fecha invalido. Use DD-MM-AAAA.", "NO VALIDO", JOptionPane.ERROR_MESSAGE);
        return;
    }


    //validar hora
    String hora = txt_hora.getText().trim();
    if (!hora.matches("\\d{2}:\\d{2}")) {
        JOptionPane.showMessageDialog(this, "Formato de hora invalido. Use HH:MM.", "NO VALIDO", JOptionPane.ERROR_MESSAGE);
        return;
    }

    
    String nombrePaciente = cbx_pacientes.getSelectedItem().toString();
    String[] pacientePartes = nombrePaciente.split(" ");
    if (pacientePartes.length < 1) {
        JOptionPane.showMessageDialog(this, "Error al obtener la cedula del paciente.", "NO VALIDO", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    
    String cedula = pacientePartes[0];
    PacienteModelo pm = pc.obtenerCedula(cedula);
    if (pm == null) {
        JOptionPane.showMessageDialog(this, "Paciente no encontrado.", "NO VALIDO", JOptionPane.ERROR_MESSAGE);
        return;
    }

    
    String nombreMedico = cbx_medicos.getSelectedItem().toString();
    String[] medicoPartes = nombreMedico.split(" ");
    if (medicoPartes.length < 1) {
        JOptionPane.showMessageDialog(this, "Error al obtener la cedula del medico.", "NO VALIDO", JOptionPane.ERROR_MESSAGE);
        return;
    }
    String cedula_m = medicoPartes[0];
    MedicoModelo mm = mc.obtenerCedula(cedula_m);
    if (mm == null) {
        JOptionPane.showMessageDialog(this, "Medico no encontrado.", "NO VALIDO", JOptionPane.ERROR_MESSAGE);
        return;
    }

    
    EspecialidadModelo e = mm.getModelo();
    if (e == null) {
        JOptionPane.showMessageDialog(this, "El medico seleccionado no tiene una especialidad asignada.", "NO VALIDO", JOptionPane.ERROR_MESSAGE);
        return;
    }

    
    String estado = cbx_estado.getSelectedItem().toString();
    boolean atendido = estado.equalsIgnoreCase("Atendido"); 

    
    CitaModelo cm = cc.guardar(pm, mm, e, txt_descripcion.getText().trim(), fecha, hora, atendido);
    if (cm == null) {
        JOptionPane.showMessageDialog(this, "No se pudo registrar la cita.", "Intente nuevamente", JOptionPane.ERROR_MESSAGE);
        return;
    }
    
    JOptionPane.showMessageDialog(this, 
        "Cita ingresada a las " + cm.getHora() + 
        " el dia " + cm.getFecha() + "."+
        " Medico: " + cm.getMm().getNombre() + 
        " con especialidad " + cm.getEm().getNombre()+"."+ " Estado: "+cm.getEstadoTexto(), 
        "Éxito", JOptionPane.INFORMATION_MESSAGE);

    
    cbx_pacientes.setSelectedIndex(0);
    cbx_especialidades.setSelectedIndex(0);
    cbx_medicos.setSelectedIndex(0);
    cbx_estado.setSelectedIndex(0); 
    txt_descripcion.setText("");
    txt_fecha.setText("");
    txt_hora.setText("");
    
    }//GEN-LAST:event_btn_guardarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_guardar;
    private javax.swing.JComboBox<String> cbx_especialidades;
    private javax.swing.JComboBox<String> cbx_estado;
    private javax.swing.JComboBox<String> cbx_medicos;
    private javax.swing.JComboBox<String> cbx_pacientes;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txt_descripcion;
    private javax.swing.JTextField txt_fecha;
    private javax.swing.JTextField txt_hora;
    // End of variables declaration//GEN-END:variables
}
