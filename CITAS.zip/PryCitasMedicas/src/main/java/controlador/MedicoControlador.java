
package controlador;

import java.util.ArrayList;
import modelo.EspecialidadModelo;
import modelo.MedicoModelo;

public class MedicoControlador {
    ArrayList<MedicoModelo> medicoModelo;
    private static MedicoControlador instancia;

    private MedicoControlador() {
        this.medicoModelo = new ArrayList<>();
    }
    public static MedicoControlador getInstancia(){
        if(instancia==null){
            instancia= new MedicoControlador();
        }
    return instancia;
    }
    
    public MedicoModelo guardar(EspecialidadModelo modelo, String Cedula, String nombre, int edad, boolean sexo){
        MedicoModelo mm=new MedicoModelo(modelo, Cedula, nombre, edad, sexo);
        medicoModelo.add(mm);
        return mm;
    }
    public ArrayList<MedicoModelo> listadoCompleto(){
        return medicoModelo;
    }
    public ArrayList<MedicoModelo> listadoPorEspecialidad(String n_e){
         ArrayList<MedicoModelo>nuevoListado=new ArrayList<>();
     for (MedicoModelo mm : medicoModelo) {
         if(mm.getModelo().getNombre().contains(n_e)){
             nuevoListado.add(mm);   
         }
     }
     return nuevoListado;
    }
     public ArrayList<MedicoModelo> listadoCompletoPorCedula(String cedula){
    ArrayList<MedicoModelo>nuevoListado=new ArrayList<>();
     for (MedicoModelo mm : medicoModelo) {
         if(mm.getCedula().contains(cedula)){
             nuevoListado.add(mm);   
         }
     }
     return nuevoListado;
}
     public MedicoModelo obtenerCedula(String cedula){
     for (MedicoModelo mm : medicoModelo) {
         if(mm.getCedula().equals(cedula)){
             return mm;
         }
     }
return null;
 }
     public boolean existeCedula(String cedula) {
    for (MedicoModelo medico : listadoCompleto()) {
        if (medico.getCedula().equals(cedula)) {
            return true; // La cédula ya existe
        }
    }
    return false; // La cédula no existe
}
     public boolean eliminarMedico(String cedula) {
    for (MedicoModelo medico : listadoCompleto()) {
        if (medico.getCedula().equals(cedula)) {
            listadoCompleto().remove(medico); // Eliminar de la lista
            return true; // Éxito
        }
    }
    return false; // No se encontró el médico
}
     public boolean modificarMedico(String cedula, String nuevoNombre, int nuevaEdad, boolean nuevoSexo, EspecialidadModelo nuevaEspecialidad) {
    for (MedicoModelo medico : listadoCompleto()) {
        if (medico.getCedula().equals(cedula)) {
            // Actualizar los datos del médico
            medico.setNombre(nuevoNombre);
            medico.setEdad(nuevaEdad);
            medico.setSexo(nuevoSexo);
            medico.setModelo(nuevaEspecialidad);
            return true; // Éxito
        }
    }
    return false; // No se encontró el médico
}
}
