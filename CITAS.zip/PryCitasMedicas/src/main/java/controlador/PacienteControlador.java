
package controlador;

import java.util.ArrayList;
import modelo.PacienteModelo;

public class PacienteControlador {
    public ArrayList<PacienteModelo>pacientemodeloLista;
    private static PacienteControlador instancia;
    
    private PacienteControlador(){
        this.pacientemodeloLista=new ArrayList<>();
    }
    public static PacienteControlador getInstancia(){
        if(instancia==null){
            instancia=new PacienteControlador();
        }
        return instancia;
    }
    
    public PacienteModelo guardarDatos(String cedula, String nombres, int edad, boolean sexo) {
        PacienteModelo modelo = new PacienteModelo(cedula, nombres, edad, sexo);
        pacientemodeloLista.add(modelo);
        return modelo;
    }
   public ArrayList<PacienteModelo> listadoCompleto(){
    return pacientemodeloLista;
}
   
    public ArrayList<PacienteModelo> listadoCompletoPorCedula(String cedula){
    ArrayList<PacienteModelo>nuevoListado=new ArrayList<>();
     for (PacienteModelo pacienteModelo : pacientemodeloLista) {
         if(pacienteModelo.getCedula().contains(cedula)){
             nuevoListado.add(pacienteModelo);   
         }
     }
     return nuevoListado;
}
     public ArrayList<PacienteModelo> getPacientes() {
    return pacientemodeloLista;
}
     public PacienteModelo buscarPacientePorNombre(String nombre) {
    for (PacienteModelo paciente : listadoCompleto()) {
        if (paciente.getNombre().equals(nombre)) {
            return paciente;
        }
    }
    return null;
}
    public PacienteModelo obtenerCedula(String cedula){
     for (PacienteModelo pm : pacientemodeloLista) {
         if(pm.getCedula().equals(cedula)){
             return pm;
         }
     }
        return null;
 }
    public boolean existeCedula(String cedula) {
    // Aquí debes implementar la lógica para verificar si la cédula ya existe
    // Por ejemplo, consultar la base de datos o una lista de pacientes
    for (PacienteModelo paciente : listadoCompleto()) { // Suponiendo que tienes una lista de pacientes
        if (paciente.getCedula().equals(cedula)) {
            return true; // La cédula ya existe
        }
    }
    return false; // La cédula no existe
}
    public boolean eliminarPaciente(String cedula) {
    // Iterar sobre la lista de pacientes
    for (PacienteModelo paciente : pacientemodeloLista) {
        if (paciente.getCedula().equals(cedula)) {
            pacientemodeloLista.remove(paciente); // Eliminar el paciente de la lista
            return true; // Éxito
        }
    }
    return false; // No se encontró el paciente
}
    public boolean modificarPaciente(String cedula, String nuevoNombre, int nuevaEdad, boolean nuevoSexo) {
    for (PacienteModelo paciente : listadoCompleto()) {
        if (paciente.getCedula().equals(cedula)) {
            // Actualizar los datos del paciente
            paciente.setNombre(nuevoNombre);
            paciente.setEdad(nuevaEdad);
            paciente.setSexo(nuevoSexo);
            return true; // Éxito
        }
    }
    return false; // No se encontró el paciente
}
 
}
