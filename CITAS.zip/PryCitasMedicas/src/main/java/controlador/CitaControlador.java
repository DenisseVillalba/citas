

package controlador;


import java.util.ArrayList;
import java.util.List;
import modelo.CitaModelo;
import modelo.EspecialidadModelo;
import modelo.MedicoModelo;
import modelo.PacienteModelo;

public class CitaControlador {
    
    public ArrayList<CitaModelo> citaModelos;
    private static CitaControlador instancia;
    
    
    private CitaControlador(){
    citaModelos=new ArrayList<>();
    }
    //metodo singleton
    public static CitaControlador getInstancia(){
        if(instancia==null){
        instancia=new CitaControlador();
    }
        return instancia;
    }
    
    //metodo guardar
    public CitaModelo guardar (PacienteModelo pm, MedicoModelo mm, EspecialidadModelo em, String descripcion, String fecha, String hora, boolean atendido){
    CitaModelo nuevaCita = new CitaModelo(pm, mm, em, descripcion, fecha, hora, atendido);
    citaModelos.add(nuevaCita); 
    return nuevaCita;
    }
    public ArrayList<CitaModelo> listadoCompleto(){
        return citaModelos;
    }
    public List<CitaModelo> listadoCompletoPorPaciente(String nombrePaciente) {
    List<CitaModelo> citasFiltradas = new ArrayList<>();
    
    
    actualizarCitas();  
    
    for (CitaModelo cita : listadoCompleto()) {
        if (cita.getPm() != null && cita.getPm().getNombre().equals(nombrePaciente)) {
            citasFiltradas.add(cita);
        }
    }
    return citasFiltradas;
    }


    private void actualizarCitas() {

}

    public List<CitaModelo> listadoCompletoPorEspecialidad(String nombreEspecialidad) {
    List<CitaModelo> citasFiltradas = new ArrayList<>();
        for (CitaModelo cita : listadoCompleto()) {
        
        if (cita.getEm() != null && cita.getEm().getNombre().equals(nombreEspecialidad)) {
            citasFiltradas.add(cita);
        }
    }
    return citasFiltradas;
}
    public List<CitaModelo> listadoCompletoPorMedico(String nombreMedico) {
    List<CitaModelo> citasFiltradas = new ArrayList<>();
        for (CitaModelo cita : listadoCompleto()) {
        
        if (cita.getMm() != null && cita.getMm().getNombre().equals(nombreMedico)) {
            citasFiltradas.add(cita);
        }
    }
    return citasFiltradas;
}
     public ArrayList<CitaModelo> listadoCompletoPorFecha(String fecha){
    ArrayList<CitaModelo>nuevoListado=new ArrayList<>();
     for (CitaModelo cm : listadoCompleto()) {
         if(cm.getFecha().contains(fecha)){
             nuevoListado.add(cm);   
         }
     }
     return nuevoListado;
}
    public List<CitaModelo> listadoCompletoPorEstado(boolean atendido) {
    List<CitaModelo> citasFiltradas = new ArrayList<>();
    for (CitaModelo cita : listadoCompleto()) { 
        if (cita.isAtendido() == atendido) { 
            citasFiltradas.add(cita);
        }
    }
    return citasFiltradas;
}
    public boolean eliminarCita(String fecha, String hora, String paciente, String medico) {
    for (CitaModelo cita : listadoCompleto()) {
        if (cita.getFecha().equals(fecha) && cita.getHora().equals(hora) &&
            cita.getPm().getNombre().equals(paciente) && cita.getMm().getNombre().equals(medico)) {
            listadoCompleto().remove(cita); 
            return true; 
        }
    }
    return false; 
}
    public CitaModelo buscarCitaPorDatos(String fecha, String hora, String paciente, String medico) {
    for (CitaModelo cita : citaModelos) {
        // Verificar si los datos coinciden
        if (cita.getFecha().equals(fecha) &&
            cita.getHora().equals(hora) &&
            cita.getPm().getNombre().equals(paciente) &&
            cita.getMm().getNombre().equals(medico)) {
            return cita; // Retornar la cita encontrada
        }
    }
    return null; // Retornar null si no se encuentra la cita
}
    public boolean modificarCita(
    String fechaActual, String horaActual, String pacienteActual, String medicoActual, // Datos actuales para buscar la cita
    String nuevaFecha, String nuevaHora, String nuevoPaciente, String nuevoMedico, 
    String nuevaEspecialidad, String nuevaDescripcion, boolean nuevoEstado
) {
    // Buscar la cita en la lista usando los datos actuales
    CitaModelo cita = buscarCitaPorDatos(fechaActual, horaActual, pacienteActual, medicoActual);
    
    if (cita != null) {
        // Actualizar todos los campos de la cita
        cita.setFecha(nuevaFecha);
        cita.setHora(nuevaHora);
        cita.getPm().setNombre(nuevoPaciente); // Actualizar paciente
        cita.getMm().setNombre(nuevoMedico);   // Actualizar médico
        cita.getEm().setNombre(nuevaEspecialidad); // Actualizar especialidad
        cita.setDescripcion(nuevaDescripcion);
        cita.setAtendido(nuevoEstado);
        
        // Guardar los cambios en la base de datos
        return actualizarCitaEnBaseDeDatos(cita);
    }
    
    return false; // Retornar false si no se encontró la cita
}
    private boolean actualizarCitaEnBaseDeDatos(CitaModelo cita) {
    // Lógica para actualizar la cita en la base de datos
    try {
        // Ejemplo de consulta SQL UPDATE
        String sql = "UPDATE citas SET fecha = ?, hora = ?, paciente = ?, medico = ?, especialidad = ?, descripcion = ?, atendido = ? WHERE fecha = ? AND hora = ? AND paciente = ? AND medico = ?";
        
        
        return true; // Retornar true si la actualización fue exitosa
    } catch (Exception e) {
        e.printStackTrace();
        return false; // Retornar false si ocurrió un error
    }
}
}

