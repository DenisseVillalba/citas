
package controlador;

import java.util.ArrayList;
import modelo.EspecialidadModelo;

public class EspecialidadControlador {
    ArrayList<EspecialidadModelo>modelo;
    private static EspecialidadControlador instancia;
    private EspecialidadControlador(){
        this.modelo= new ArrayList<>();
    }
    public static EspecialidadControlador getInstancia(){
        if(instancia==null){
            instancia=new EspecialidadControlador();
            
        }
        return instancia;
    }
    public EspecialidadModelo guardar(String nombre){
        EspecialidadModelo e=new EspecialidadModelo(nombre);
        modelo.add(e);
        return e;
    }
    public ArrayList<EspecialidadModelo> listado(){
        return modelo;
    }
    public EspecialidadModelo obtenerPorNombre(String nombre){
        for (EspecialidadModelo e : modelo) {
            if(e.getNombre().equals(nombre)){
                return e;
            }
        }
        return null;
    }
     public ArrayList<EspecialidadModelo> listadoCompletoPorNombre(String nombre){
    ArrayList<EspecialidadModelo>nuevoListado=new ArrayList<>();
     for (EspecialidadModelo e : modelo) {
         if(e.getNombre().contains(nombre)){
             nuevoListado.add(e);   
         }
     }
     return nuevoListado;
}
     public boolean eliminarEspecialidad(String nombre) {
    for (EspecialidadModelo especialidad : listado()) {
        if (especialidad.getNombre().equals(nombre)) {
            listado().remove(especialidad); // Eliminar de la lista
            return true; // Éxito
        }
    }
    return false; // No se encontró la especialidad
}
     public boolean modificarEspecialidad(String nombre, String nuevoNombre) {
    for (EspecialidadModelo especialidad : listado()) {
        if (especialidad.getNombre().equals(nombre)) {
            // Actualizar los datos de la especialidad
            especialidad.setNombre(nuevoNombre);
            return true; // Éxito
        }
    }
    return false; // No se encontró la especialidad
}
}
