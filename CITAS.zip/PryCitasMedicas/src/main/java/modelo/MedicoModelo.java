
package modelo;

public class MedicoModelo extends PacienteModelo {
    public EspecialidadModelo modelo;

    public MedicoModelo(EspecialidadModelo modelo, String Cedula, String nombre, int edad, boolean sexo) {
        super(Cedula, nombre, edad, sexo);
        this.modelo = modelo;
    }

    public EspecialidadModelo getModelo() {
        return modelo;
    }

    public void setModelo(EspecialidadModelo modelo) {
        this.modelo = modelo;
    }   
}
